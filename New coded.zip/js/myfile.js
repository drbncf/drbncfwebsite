$(document).ready(function(){
        $('.tlt').textillate();
    });
