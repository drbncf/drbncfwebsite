$(document).ready(function(){
        $('.tlt').textillate({ 
		  in: { effect: 'fadeInUp', sync: true },
		  loop: false
		});
    });